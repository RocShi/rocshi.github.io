#include <iostream>
#include "LeastSquareMethod.h"

using namespace std;

int main()
{
    float x[5] = {1, 2, 3, 4, 5};
    float y[5] = {7, 35, 103, 229, 431};

    vector<float> X(x, x + sizeof(x) / sizeof(float));
    vector<float> Y(y, y + sizeof(y) / sizeof(float));

    Eigen::VectorXf result1(FitterLeastSquareMethod(X, Y, 3));
    cout << "\nThe coefficients vector is: \n" << endl;
    for (size_t i = 0; i < result1.size(); ++i)
        cout << "theta_" << i << ": " << result1[i] << endl;

    Eigen::VectorXf result2(LU(X, Y, 3));
    cout << "\nThe coefficients vector is: \n" << endl;
    for (size_t i = 0; i < result2.size(); ++i)
        cout << "theta_" << i << ": " << result2[i] << endl;
    
    Eigen::VectorXf result3(QR(X, Y, 3));
    cout << "\nThe coefficients vector is: \n" << endl;
    for (size_t i = 0; i < result3.size(); ++i)
        cout << "theta_" << i << ": " << result3[i] << endl;
    
    Eigen::VectorXf result4(SVD(X, Y, 3));
    cout << "\nThe coefficients vector is: \n" << endl;
    for (size_t i = 0; i < result4.size(); ++i)
        cout << "theta_" << i << ": " << result4[i] << endl;
    
    Eigen::VectorXf result5(LDLT(X, Y, 3));
    cout << "\nThe coefficients vector is: \n" << endl;
    for (size_t i = 0; i < result5.size(); ++i)
        cout << "theta_" << i << ": " << result5[i] << endl;

    Eigen::VectorXf result6(GD(X, Y, 3));
    cout << "\nThe coefficients vector is: \n" << endl;
    for (size_t i = 0; i < result6.size(); ++i)
        cout << "theta_" << i << ": " << result6[i] << endl;

    return 0;
}
