#ifndef DATA_STRUCTURE_
#define DATA_STRUCTURE_

#include <vector>

/**
 * @brief Structure of landmark in global map coordinate. 
 * 
 */
struct LandMark_Map
{
    uint32_t id; // Landmark ID
    double x;    // Landmark x-position in the map (global coordinates)
    double y;    // Landmark y-position in the map (global coordinates)
};

/**
 * @brief Structure of landmark in local ego vehicle coordinate.
 * 
 */
struct LandMark_Ego
{
    uint32_t id; // Id of matching landmark in the map
    double x;    // Local (vehicle coords) x position of landmark observation [m]
    double y;    // Local (vehicle coords) y position of landmark observation [m]
};

#endif
