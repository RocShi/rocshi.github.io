#include "math.h"

#include "ParticleFilter.h"

/**
 * @brief Construct a new Unscented Kalman Filter object
 *
 */
ParticleFilter::ParticleFilter()
    : is_inited(false),
      just_begin_filt(false),
      timestamp_last(0),
      timestamp_now(0),
      n_p(1000),
      sigma_gps{0.3, 0.3, 0.01},
      sigma_landmark{0.3, 0.3},
      sensor_range(100.0),
      dt(0.0),
      particles(3, n_p),
      particles_re(3, n_p),
      weights_nonnormalized(n_p),
      weights_normalized(n_p),
      weights_re(n_p),
      estimated_state()
{
}

/**
 * @brief Destroy the Unscented Kalman Filter object
 *
 */
ParticleFilter::~ParticleFilter() {}

/**
 * @brief Initialize the particle filter.
 * 
 * @param x Initial x position [m] from GPS.
 * @param y Initial y position [m] from GPS.
 * @param theta Initial heading angle [rad] from GPS.
 * @param std_pos Array of dimension 3 [standard deviation of x [m], 
 *   standard deviation of y [m], standard deviation of theta [rad]]
 */
void ParticleFilter::Init(const double &x, const double &y, const double &theta,
                          const double std_pos[])
{
    if (!IsInited())
    {
        // create normal distributions around the initial gps measurement values
        std::default_random_engine gen;
        std::normal_distribution<double> norm_dist_x(x, std_pos[0]);
        std::normal_distribution<double> norm_dist_y(y, std_pos[1]);
        std::normal_distribution<double> norm_dist_theta(theta, std_pos[2]);

        // initialize particles one by one
        for (size_t i = 0; i < n_p; ++i)
        {
            particles(0, i) = norm_dist_x(gen);
            particles(1, i) = norm_dist_y(gen);
            particles(2, i) = norm_dist_theta(gen);
        }

        // initialize weights to 1 / n_p
        weights_nonnormalized.fill(1 / n_p);
        weights_normalized.fill(1 / n_p);

        is_inited = true;
    }
}

/**
 * @brief Predict new state of particle according to the system motion model.
 * 
 * @param velocity Velocity of car [m/s]
 * @param yaw_rate Yaw rate of car [rad/s]
 * @param delta_t delta time between last timestamp and current timestamp [s]
 * @param std_pos Array of dimension 3 [standard deviation of x [m], 
 *   standard deviation of y [m], standard deviation of yaw [rad]]
 */
void ParticleFilter::Predict(const double &velocity, const double &yaw_rate,
                             const double &delta_t, const double std_pos[])
{
    if (!IsInited())
        return;

    // create process noise's normal distributions of which the mean is zero
    std::default_random_engine gen;
    std::normal_distribution<double> norm_dist_x(0, std_pos[0]);
    std::normal_distribution<double> norm_dist_y(0, std_pos[1]);
    std::normal_distribution<double> norm_dist_theta(0, std_pos[2]);

    // predict state of particles one by one
    for (size_t i = 0; i < n_p; ++i)
    {
        double theta_last = particles(2, i);

        Eigen::VectorXd state_trans_item_motion(3);
        Eigen::VectorXd state_trans_item_noise(3);

        state_trans_item_noise << norm_dist_x(gen), norm_dist_y(gen), norm_dist_theta(gen);

        if (std::fabs(yaw_rate) > 0.001) // CTRV model
        {
            state_trans_item_motion << velocity / yaw_rate * (sin(theta_last + yaw_rate * delta_t) - sin(theta_last)),
                velocity / yaw_rate * (-cos(theta_last + yaw_rate * delta_t) + cos(theta_last)),
                yaw_rate * delta_t;
        }
        else // approximate CV model
        {
            state_trans_item_motion << velocity * cos(theta_last) * delta_t,
                velocity * sin(theta_last) * delta_t,
                yaw_rate * delta_t;
        }

        // predict new state of the ith particle
        particles.col(i) = particles.col(i) + state_trans_item_motion + state_trans_item_noise;

        // normalize theta
        NormalizeAngle(particles(2, i));
    }
}

/**
 * @brief 
 * 
 * @param lmrks_obs Observed landmarks in local ego vehicle coordinate.
 * @param snsr_range Sensor measuremet range.
 * @param lmrks_map All map landmarks.
 * @param std_lmrks Array of dimension 2 [Landmark measurement uncertainty 
 *   [x [m], y [m]]]
 */
void ParticleFilter::Update(const std::vector<LandMark_Ego> &lmrks_obs,
                            const double &snsr_range,
                            const std::vector<LandMark_Map> &lmrks_map,
                            const double std_lmrks[])
{
    // process particles one by one
    for (size_t i = 0; i < n_p; ++i)
    {
        // step1: transform observed landmarks from local ego vehicle coordinate
        // to global map coordinate
        std::vector<LandMark_Map> landmarks_trans2map(lmrks_obs.size());
        TransLandmarksFromVehicle2Map(lmrks_obs, particles.col(i), landmarks_trans2map);

        // step2: find map landmarks within the sensor measuremet range
        std::vector<LandMark_Map> landmarks_within_sensor_range;
        FindMapLandmarksWithinSensorRange(lmrks_map, particles.col(i), snsr_range,
                                          landmarks_within_sensor_range);

        // step3: associate observed landmarks which have been transformed to
        // global map coordinate with map landmarks within the sensor measuremet
        // range
        DataAssociation(landmarks_within_sensor_range, landmarks_trans2map);

        // step4: for each observed landmark with an associated landmark, calculate
        // its' weight contribution, and then multiply to particle's final weight
        UpdateWeight(landmarks_trans2map, lmrks_map, std_lmrks, weights_nonnormalized(i));
    }
}

/**
 * @brief Multinomial resampling method.
 * 
 * @param particles_ori Particles before resampling.
 * @param weights_ori_norm Normalized weights before resampling.
 * @param particles_resampled Particles after resampling.
 * @param weights_resampled Weights after resampling.
 * @param N_r Number of particles to resample.
 */
void ParticleFilter::MultinomialResampling(const Eigen::MatrixXd &particles_ori,
                                           const Eigen::VectorXd &weights_ori_norm,
                                           Eigen::MatrixXd &particles_resampled,
                                           Eigen::VectorXd &weights_resampled,
                                           uint32_t N_r)
{
    uint32_t N = weights_ori_norm.size();
    uint32_t left, right, middle;

    Eigen::VectorXd weights_cum_sum = CalcWeightsCumSum(weights_ori_norm);

    for (size_t j = N - N_r; j < N; ++j)
    {
        // produces random values u, uniformly distributed on the interval [0.0, 1.0)
        std::random_device rd;
        std::mt19937 gen(rd());
        std::uniform_real_distribution<> uniform_dist(0.0, 1.0);
        double u = uniform_dist(gen);

        // select the resampled particle using binary search
        left = 0;
        right = N - 1;
        while (left < right)
        {
            middle = std::floor((left + right) / 2);
            if (u > weights_cum_sum(middle))
                left = middle + 1;
            else
                right = middle;
        }

        particles_resampled(j) = particles_ori(right);
        weights_resampled(j) = 1 / N;
    }
}

/**
 * @brief Stratified resampling method.
 * 
 * @param particles_ori Particles before resampling.
 * @param weights_ori_norm Normalized weights before resampling.
 * @param particles_resampled Particles after resampling.
 * @param weights_resampled Weights after resampling.
 * @param N_r Number of particles to resample.
 */
void ParticleFilter::StratifiedResampling(const Eigen::MatrixXd &particles_ori,
                                          const Eigen::VectorXd &weights_ori_norm,
                                          Eigen::MatrixXd &particles_resampled,
                                          Eigen::VectorXd &weights_resampled,
                                          uint32_t N_r)
{
    uint32_t N = weights_ori_norm.size();

    Eigen::VectorXd weights_cum_sum = CalcWeightsCumSum(weights_ori_norm);

    uint32_t i = 0;

    for (size_t j = N - N_r; j < N; ++j)
    {
        // produces random values u0, uniformly distributed on the interval [0.0, 1.0 / N_r)
        // then calculate u = u0 + (j - (N - N_r)) / N_r
        std::random_device rd;
        std::mt19937 gen(rd());
        std::uniform_real_distribution<> uniform_dist(0.0, 1 / N_r);
        double u0 = uniform_dist(gen);
        double u = u0 + (j - (N - N_r)) / N_r;

        // select the resampled particle
        while (weights_cum_sum(i) < u)
            ++i;

        particles_resampled(j) = particles_ori(i);
        weights_resampled(j) = 1 / N;
    }
}

/**
 * @brief Systematic resampling method.
 * 
 * @param particles_ori Particles before resampling.
 * @param weights_ori_norm Normalized weights before resampling.
 * @param particles_resampled Particles after resampling.
 * @param weights_resampled Weights after resampling.
 * @param N_r Number of particles to resample.
 */
void ParticleFilter::SystematicResampling(const Eigen::MatrixXd &particles_ori,
                                          const Eigen::VectorXd &weights_ori_norm,
                                          Eigen::MatrixXd &particles_resampled,
                                          Eigen::VectorXd &weights_resampled,
                                          uint32_t N_r)
{
    uint32_t N = weights_ori_norm.size();

    Eigen::VectorXd weights_cum_sum = CalcWeightsCumSum(weights_ori_norm);

    uint32_t i = 0;

    // produces random values u0, uniformly distributed on the interval [0.0, 1.0 / N_r)
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_real_distribution<> uniform_dist(0.0, 1 / N_r);
    double u0 = uniform_dist(gen);

    for (size_t j = N - N_r; j < N; ++j)
    {
        // calculate u = u0 + (j - (N - N_r)) / N_r
        double u = u0 + (j - (N - N_r)) / N_r;

        // select the resampled particle
        while (weights_cum_sum(i) < u)
            ++i;

        particles_resampled(j) = particles_ori(i);
        weights_resampled(j) = 1 / N;
    }
}

/**
 * @brief Residual resampling method.
 * 
 * @param particles_ori Particles before resampling.
 * @param weights_ori_norm Normalized weights before resampling.
 * @param particles_resampled Particles after resampling.
 * @param weights_resampled Weights after resampling.
 */
void ParticleFilter::ResidualResampling(const Eigen::MatrixXd &particles_ori,
                                        const Eigen::VectorXd &weights_ori_norm,
                                        Eigen::MatrixXd &particles_resampled,
                                        Eigen::VectorXd &weights_resampled)
{
    uint32_t N = weights_ori_norm.size();
    uint32_t j = 0;
    Eigen::VectorXi N_k1(N);

    // step1: deterministic copy sampling
    for (size_t i = 0; i < N; ++i)
    {
        N_k1(i) = std::floor(N * weights_ori_norm(i));

        for (size_t m = 0; m < N_k1(i); ++m)
        {
            particles_resampled(j) = particles_ori(i);
            weights_resampled(j) = 1 / N;
            ++j;
        }
    }

    // step2: residual random sampling
    uint32_t N_k2 = N - j;
    Eigen::VectorXd weights_residual_norm = (N * weights_ori_norm - N_k1) / N_k2;
    MultinomialResampling(particles_ori, weights_residual_norm, particles_resampled,
                          weights_resampled, N_k2);
}

/**
 * @brief Transform observed landmarks from local ego vehicle coordinate to 
 *   global map coordinate.
 * 
 * @param lmrks_obs Observed landmarks in local ego vehicle coordinate.
 * @param particle Single particle with state of [x, y, theta]
 * @param lmrks_trans2map Observed landmarks transformed from local ego vehicle 
 *   coordinate to global map coordinate.
 */
void ParticleFilter::TransLandmarksFromVehicle2Map(const std::vector<LandMark_Ego> &lmrks_obs,
                                                   const Eigen::Vector3d &particle,
                                                   std::vector<LandMark_Map> &lmrks_trans2map)
{
    for (size_t i = 0; i < lmrks_obs.size(); ++i)
    {
        lmrks_trans2map[i].x = lmrks_obs[i].x * cos(particle(2)) -
                               lmrks_obs[i].y * sin(particle(2)) + particle(0);

        lmrks_trans2map[i].y = lmrks_obs[i].x * sin(particle(2)) +
                               lmrks_obs[i].y * cos(particle(2)) + particle(1);
    }
}

/**
 * @brief Find map landmarks within the sensor measuremet range.
 * 
 * @param lmrks_map All map landmarks.
 * @param particle Single particle with state of [x, y, theta]
 * @param snsr_range Sensor measuremet range.
 * @param lmrks_within_range Map landmarks within the sensor measuremet range.
 */
void ParticleFilter::FindMapLandmarksWithinSensorRange(const std::vector<LandMark_Map> &lmrks_map,
                                                       const Eigen::Vector3d &particle,
                                                       const double &snsr_range,
                                                       std::vector<LandMark_Map> &lmrks_within_range)
{
    static double distance_threshold_square = snsr_range * snsr_range;

    for (auto landmark : lmrks_map)
    {
        double distance_square = std::pow(particle(0) - landmark.x, 2) +
                                 std::pow(particle(1) - landmark.y, 2);

        if (distance_square <= distance_threshold_square)
            lmrks_within_range.push_back(landmark);
    }
}

/**
 * @brief Associate observed landmarks which have been transformed to global 
 *   map coordinate with map landmarks within the sensor measuremet range.
 * 
 * @param lmrks_within_range Map landmarks within the sensor measuremet range.
 * @param lmrks_trans2map Observed landmarks transformed from local ego vehicle 
 *   coordinate to global map coordinate.
 */
void ParticleFilter::DataAssociation(const std::vector<LandMark_Map> &lmrks_within_range,
                                     std::vector<LandMark_Map> &lmrks_trans2map)
{
    for (auto &landmark_trans2map : lmrks_trans2map)
    {
        double distance_min = std::numeric_limits<double>::max();

        for (auto &landmark_within_range : lmrks_within_range)
        {
            double distance_square = std::pow(landmark_trans2map.x - landmark_within_range.x, 2) +
                                     std::pow(landmark_trans2map.y - landmark_within_range.y, 2);

            if (distance_square < distance_min)
            {
                distance_min = distance_square;
                landmark_trans2map.id = landmark_within_range.id;
            }
        }
    }
}

/**
 * @brief For each observed landmark with an associated landmark, calculate 
 *   its' weight contribution, and then multiply to particle's final weight.
 * 
 * @param lmrks_trans2map Observed landmarks transformed from local ego vehicle
 *   coordinate to global map coordinate.
 * @param lmrks_map All map landmarks.
 * @param std_lmrks Array of dimension 2 [Landmark measurement uncertainty 
 *   [x [m], y [m]]]
 * @param weight Non-normalized weight of particle.
 */
void ParticleFilter::UpdateWeight(const std::vector<LandMark_Map> &lmrks_trans2map,
                                  const std::vector<LandMark_Map> &lmrks_map,
                                  const double std_lmrks[],
                                  double &weight)
{
    double likelyhood_probability_particle = 1.0;
    double sigma_x = std_lmrks[0];
    double sigma_y = std_lmrks[1];

    for (auto &landmark_trans2map : lmrks_trans2map)
    {
        double x = landmark_trans2map.x;
        double y = landmark_trans2map.y;
        double ux = lmrks_map.at(landmark_trans2map.id - 1).x;
        double uy = lmrks_map.at(landmark_trans2map.id - 1).y;
        double exponent = -(std::pow(x - ux, 2) / (2 * std::pow(sigma_x, 2)) +
                            std::pow(y - uy, 2) / (2 * std::pow(sigma_y, 2)));
        double likelyhood_probability_landmark = 1.0 / (2 * M_PI * sigma_x * sigma_y) *
                                                 std::exp(exponent);
        likelyhood_probability_particle *= likelyhood_probability_landmark;
    }

    weight *= likelyhood_probability_particle;
}
