#include "ParticleFilter.h"

int main()
{
    ParticleFilter pf;                   // particle filter instance
    double x, y, theta;                  // gps measurement data
    double v, yaw_rate;                  // input control data
    std::vector<LandMark_Ego> lmrks_obs; // observed landmarks in local ego vehicle coordinate
    std::vector<LandMark_Map> lmrks_map; // map landmarks

    while (true)
    {
        pf.RecvRawData(x, y, theta, v, yaw_rate, lmrks_obs, lmrks_map);

        pf.Init(x, y, theta, pf.sigma_gps);
        pf.Predict(v, yaw_rate, pf.dt, pf.sigma_gps);
        pf.Update(lmrks_obs, pf.sensor_range, lmrks_map, pf.sigma_landmark);
        pf.NormalizeWeights(pf.weights_nonnormalized, pf.weights_normalized);
        pf.SystematicResampling(pf.particles, pf.weights_normalized,
                                pf.particles_re, pf.weights_re, pf.n_p);
        pf.estimated_state = pf.EstimateState(pf.particles_re, pf.weights_re,
                                              pf.particles, pf.weights_normalized,
                                              pf.weights_nonnormalized);
    }

    return 0;
}
