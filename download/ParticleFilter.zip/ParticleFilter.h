#ifndef PARTICLE_FILTER_
#define PARTICLE_FILTER_

#include <vector>
#include <random>

#include "Eigen/Dense"
#include "DataStructure.h"

class ParticleFilter
{
private:
    bool is_inited;          // flag of initialization
    bool just_begin_filt;    // flag of just begining filt data
    uint64_t timestamp_last; // timestamp of last frame [us]
    uint64_t timestamp_now;  // timestamp of current frame [us]

public:
    uint32_t n_p;                          // number of particles
    double sigma_gps[3];                   // gps measurement uncertainty [x [m], y [m], theta [rad]]
    double sigma_landmark[2];              // Landmark measurement uncertainty [x [m], y [m]]
    double sensor_range;                   // sensor measuremet range
    double dt;                             // delta time [s]
    Eigen::MatrixXd particles;             // set of particles
    Eigen::MatrixXd particles_re;          // set of resampled particles
    Eigen::VectorXd weights_nonnormalized; // non-normalized weights of particles
    Eigen::VectorXd weights_normalized;    // normalized weights of particles
    Eigen::VectorXd weights_re;            // weights of particles after resampling
    Eigen::Vector3d estimated_state;       // the final estimated state of system

public:
    /**
     * @brief Construct a new Particle Filter object
     * 
     */
    ParticleFilter();

    /**
     * @brief Destroy the Particle Filter object
     * 
     */
    ~ParticleFilter();

    /**
     * @brief Return the initialization status of the pf instance.
     *
     * @return bool Whether or not the filter has been initialized.
     */
    inline bool IsInited() { return is_inited; }

    /**
     * @brief Reset the pf instance.
     *
     */
    inline void Reset() { is_inited = false; }

    /**
     * @brief Normalize the input angle to [-PI, PI].
     *
     * @param angle Angle to be normalized.
     */
    inline void NormalizeAngle(double &angle)
    {
        while (angle > M_PI)
            angle -= 2.0 * M_PI;
        while (angle < -M_PI)
            angle += 2.0 * M_PI;
    }

    /**
     * @brief Transform observed landmarks from local ego vehicle coordinate to 
     *   global map coordinate.
     * 
     * @param lmrks_obs Observed landmarks in local ego vehicle coordinate.
     * @param particle Single particle with state of [x, y, theta]
     * @param lmrks_trans2map Observed landmarks transformed from local ego vehicle 
     *   coordinate to global map coordinate.
     */
    void TransLandmarksFromVehicle2Map(const std::vector<LandMark_Ego> &lmrks_obs,
                                       const Eigen::Vector3d &particle,
                                       std::vector<LandMark_Map> &lmrks_trans2map);

    /**
     * @brief Find map landmarks within the sensor measuremet range.
     * 
     * @param lmrks_map All map landmarks.
     * @param particle Single particle with state of [x, y, theta]
     * @param snsr_range Sensor measuremet range.
     * @param lmrks_within_range Map landmarks within the sensor measuremet range.
     */
    void FindMapLandmarksWithinSensorRange(const std::vector<LandMark_Map> &lmrks_map,
                                           const Eigen::Vector3d &particle,
                                           const double &snsr_range,
                                           std::vector<LandMark_Map> &lmrks_within_range);

    /**
     * @brief Associate observed landmarks which have been transformed to global 
     *   map coordinate with map landmarks within the sensor measuremet range.
     * 
     * @param lmrks_within_range Map landmarks within the sensor measuremet range.
     * @param lmrks_trans2map Observed landmarks transformed from local ego vehicle 
     *   coordinate to global map coordinate.
     */
    void DataAssociation(const std::vector<LandMark_Map> &lmrks_within_range,
                         std::vector<LandMark_Map> &lmrks_trans2map);

    /**
     * @brief For each observed landmark with an associated landmark, calculate 
     *   its' weight contribution, and then multiply to particle's final weight.
     * 
     * @param lmrks_trans2map Observed landmarks transformed from local ego vehicle
     *   coordinate to global map coordinate.
     * @param lmrks_map All map landmarks.
     * @param std_lmrks Array of dimension 2 [Landmark measurement uncertainty 
     *   [x [m], y [m]]]
     * @param weight Non-normalized weight of particle.
     */
    void UpdateWeight(const std::vector<LandMark_Map> &lmrks_trans2map,
                      const std::vector<LandMark_Map> &lmrks_map,
                      const double std_lmrks[],
                      double &weight);

    /**
     * @brief Calculate cumulative sum of normalized weights of particles.
     * 
     * @param weights Normalized weights of particles.
     * @return Eigen::VectorXd Cumulative sum of normalized weights of particles.
     */
    inline Eigen::VectorXd CalcWeightsCumSum(const Eigen::VectorXd &weights)
    {
        uint32_t N = weights.size();
        Eigen::VectorXd weights_cum_sum(N);

        weights_cum_sum(0) = weights(0);
        for (size_t i = 1; i < N; ++i)
            weights_cum_sum(i) = weights_cum_sum(i - 1) + weights(i);
        weights_cum_sum(N - 1) = 1.0;

        return weights_cum_sum;
    }

    /**
     * @brief Receive and update sensor data
     * 
     * @param x X position [m] from GPS.
     * @param y Y position [m] from GPS.
     * @param theta Heading angle [rad] from GPS.
     * @param velocity Velocity of car [m/s].
     * @param yaw_rate Yaw rate of car [rad/s].
     * @param lmrks_obs Observed landmarks in local ego vehicle coordinate.
     * @param lmrks_map All map landmarks.
     */
    inline void RecvRawData(double &x, double &y, double &theta, double &velocity,
                            double &yaw_rate, std::vector<LandMark_Ego> &lmrks_obs,
                            std::vector<LandMark_Map> &lmrks_map)
    {
        // receive map data from somewhere and update lmrks_map for one time

        // receive sensor data and update x
        // receive sensor data and update y
        // receive sensor data and update theta
        // receive sensor data and update velocity
        // receive sensor data and update yaw_rate
        // receive sensor data and update lmrks_obs

        // receive new timestamp and update timestamp_now

        dt = (timestamp_now - timestamp_last) / 1E6;
        timestamp_last = timestamp_now;
    }

    /**
     * @brief Initialize the particle filter.
     * 
     * @param x Initial x position [m] from GPS.
     * @param y Initial y position [m] from GPS.
     * @param theta Initial heading angle [rad] from GPS.
     * @param std_pos Array of dimension 3 [standard deviation of x [m], 
     *   standard deviation of y [m], standard deviation of theta [rad]]
     */
    void Init(const double &x, const double &y, const double &theta,
              const double std_pos[]);

    /**
     * @brief Predict new state of particle according to the system motion model.
     * 
     * @param velocity Velocity of car [m/s]
     * @param yaw_rate Yaw rate of car [rad/s]
     * @param delta_t delta time between last timestamp and current timestamp [s]
     * @param std_pos Array of dimension 3 [standard deviation of x [m], 
     *   standard deviation of y [m], standard deviation of yaw [rad]]
     */
    void Predict(const double &velocity, const double &yaw_rate,
                 const double &delta_t, const double std_pos[]);

    /**
     * @brief 
     * 
     * @param lmrks_obs Observed landmarks in local ego vehicle coordinate.
     * @param snsr_range Sensor measuremet range.
     * @param lmrks_map All map landmarks.
     * @param std_lmrks Array of dimension 2 [Landmark measurement uncertainty 
     *   [x [m], y [m]]]
     */
    void Update(const std::vector<LandMark_Ego> &lmrks_obs, const double &snsr_range,
                const std::vector<LandMark_Map> &lmrks_map, const double std_lmrks[]);

    /**
     * @brief Normalize the weights of particles.
     * 
     * @param w_nonnormalized Weights to be normalized.
     * @param w_normalized Weights which have been normalized.
     */
    inline void NormalizeWeights(const Eigen::VectorXd &w_nonnormalized,
                                 Eigen::VectorXd &w_normalized)
    {
        w_normalized = w_nonnormalized / w_nonnormalized.sum();
    }

    /**
     * @brief Multinomial resampling method.
     * 
     * @param particles_ori Particles before resampling.
     * @param weights_ori_norm Normalized weights before resampling.
     * @param particles_resampled Particles after resampling.
     * @param weights_resampled Weights after resampling.
     * @param N_r Number of particles to resample.
     */
    void MultinomialResampling(const Eigen::MatrixXd &particles_ori, const Eigen::VectorXd &weights_ori_norm,
                               Eigen::MatrixXd &particles_resampled, Eigen::VectorXd &weights_resampled,
                               uint32_t N_r);

    /**
     * @brief Stratified resampling method.
     * 
     * @param particles_ori Particles before resampling.
     * @param weights_ori_norm Normalized weights before resampling.
     * @param particles_resampled Particles after resampling.
     * @param weights_resampled Weights after resampling.
     * @param N_r Number of particles to resample.
     */
    void StratifiedResampling(const Eigen::MatrixXd &particles_ori, const Eigen::VectorXd &weights_ori_norm,
                              Eigen::MatrixXd &particles_resampled, Eigen::VectorXd &weights_resampled,
                              uint32_t N_r);

    /**
     * @brief Systematic resampling method.
     * 
     * @param particles_ori Particles before resampling.
     * @param weights_ori_norm Normalized weights before resampling.
     * @param particles_resampled Particles after resampling.
     * @param weights_resampled Weights after resampling.
     * @param N_r Number of particles to resample.
     */
    void SystematicResampling(const Eigen::MatrixXd &particles_ori, const Eigen::VectorXd &weights_ori_norm,
                              Eigen::MatrixXd &particles_resampled, Eigen::VectorXd &weights_resampled,
                              uint32_t N_r);

    /**
     * @brief Residual resampling method.
     * 
     * @param particles_ori Particles before resampling.
     * @param weights_ori_norm Normalized weights before resampling.
     * @param particles_resampled Particles after resampling.
     * @param weights_resampled Weights after resampling.
     */
    void ResidualResampling(const Eigen::MatrixXd &particles_ori, const Eigen::VectorXd &weights_ori_norm,
                            Eigen::MatrixXd &particles_resampled, Eigen::VectorXd &weights_resampled);

    /**
     * @brief Estimate the final state of system by combing all particles. 
     * 
     * @param particles_resampled Particles after resampling.
     * @param weights_resampled Weights after resampling.
     * @param particles_ori Particles before resampling.
     * @param weights_ori_norm Normalized weights before resampling.
     * @param weights_ori Non-normalized weights before resampling.
     * @return Eigen::Vector3d The final estimated state of system.
     */
    inline Eigen::Vector3d EstimateState(const Eigen::MatrixXd &particles_resampled,
                                         const Eigen::VectorXd &weights_resampled,
                                         Eigen::MatrixXd &particles_ori,
                                         Eigen::VectorXd &weights_ori_norm,
                                         Eigen::VectorXd &weights_ori)
    {
        particles_ori = particles_resampled;
        weights_ori = weights_resampled;
        weights_ori_norm = weights_resampled;

        return particles_ori * weights_ori_norm;
    }
};

#endif
