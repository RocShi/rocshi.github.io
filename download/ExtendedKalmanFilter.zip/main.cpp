#include "ExtendedKalmanFilter.h"

#include <iostream>

int main()
{
    ExtendedKalmanFilter ekf;

    while (1)
    {
        RecvRawData(ekf.Z(0), ekf.Z(1), ekf.Z(2), ekf.timestamp_now);
        Init();
        Predict();
        Update();
    }

    return 0;
}
