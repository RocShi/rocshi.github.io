#include "math.h"

#include "ExtendedKalmanFilter.h"

/**
 * @brief Construct a new Extended Kalman Filter:: Extended Kalman Filter object
 * 
 */
ExtendedKalmanFilter::ExtendedKalmanFilter()
    : is_inited(false),
      just_begin_filt(false),
      X(4),
      F(4, 4),
      P(4, 4),
      Q(4, 4),
      Z(3),
      Hj(3, 4),
      R(3, 3),
      K(4, 3),
      timestamp_now(0),
      timestamp_last(0),
      dt(0.0f)
{
}

/**
 * @brief Destroy the Extended Kalman Filter:: Extended Kalman Filter object
 * 
 */
ExtendedKalmanFilter::~ExtendedKalmanFilter() {}

/**
 * @brief Initialize the extended kalman filter.
 * 
 */
void ExtendedKalmanFilter::Init()
{
    if (!IsInited())
    {
        X << Z(0) * cos(Z(1)),
            Z(0) * sin(Z(1)),
            Z(2) * cos(Z(1)),
            Z(2) * sin(Z(1));
        P << 1.0, 0.0, 0.0, 0.0,
            0.0, 1.0, 0.0, 0.0,
            0.0, 0.0, 10.0, 0.0,
            0.0, 0.0, 0.0, 10.0;
        Q << 1.0, 0.0, 0.0, 0.0,
            0.0, 1.0, 0.0, 0.0,
            0.0, 0.0, 1.0, 0.0,
            0.0, 0.0, 0.0, 1.0;
        R << 0.09, 0.0, 0.0,
            0.0, 0.009, 0.0,
            0.0, 0.0, 0.09;
        timestamp_last = timestamp_now;
        is_inited = true;
        just_begin_filt = true;
    }
    else
        just_begin_filt = false;
}

/**
 * @brief Predict step.
 * 
 */
void ExtendedKalmanFilter::Predict()
{
    if (just_begin_filt)
        return;

    dt = (timestamp_now - timestamp_last) / 1E6;
    SetF();
    timestamp_last = timestamp_now;

    // predict state vector
    X = F * X;

    // predict state covariance matrix
    P = F * P * F.transpose() + Q;
}

/**
 * @brief Update step.
 * 
 */
void ExtendedKalmanFilter::Update()
{
    if (just_begin_filt)
        return;

    float c1 = X(0) ^ 2 + X(1) ^ 2;
    float c2 = sqrt(c1);
    float c3 = c1 * c2;
    if (fabs(c1 > 0.0001))
    {
        Hj << X(0) / c2, X(1) / c2, 0, 0,
            -X(1) / c2, X(0) / c2, 0, 0,
            X(1) * (X(2) * X(1) - X(3) * X(0)) / c3, X(0) * (X(3) * X(0) - X(2) * X(1)) / c3, X(0) / c2, X(1) / c2;
    }

    Eigen::VectorXd(3) hx;
    hx << c2, atan2(X(1), X(0)), (X(0) * X(2) + X(1) * X(3)) / c2;

    static Eigen::MatrixXd I = Eigen::MatrixXd::Identity(X.size(), X.size());

    // calculate extended kalman gain
    K = P * Hj.transpose() * (Hj * P * Hj.transpose() + R).inverse();

    // update state vector
    X = X + K * (Z - hx);

    // update state covariance matrix
    P = (I - K * Hj) * P;
}
