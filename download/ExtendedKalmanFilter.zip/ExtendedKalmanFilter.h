#ifndef EXTENDED_KALMAN_FILTER_
#define EXTENDED_KALMAN_FILTER_

#include "D:/eigen3/Eigen/Dense"

class ExtendedKalmanFilter
{
private:
    bool is_inited;          // flag of initialization
    bool just_begin_filt;    // flag of just begining filt data
    Eigen::VectorXd X;       // state vector
    Eigen::MatrixXd F;       // state transition matrix
    Eigen::MatrixXd P;       // state covariance matrix
    Eigen::MatrixXd Q;       // process noise covariance matrix
    Eigen::MatrixXd Hj;      // measurement jacobian matrix
    Eigen::MatrixXd R;       // measurement noise covariance matrix
    Eigen::MatrixXd K;       // extended kalman gain coefficient
    uint64_t timestamp_last; // timestamp of last frame: us
    float dt;                // delta time: s

public:
    Eigen::VectorXd Z;      // measurement vector
    uint64_t timestamp_now; // timestamp of current frame: us

public:
    ExtendedKalmanFilter();
    ~ExtendedKalmanFilter();

    inline bool &IsInited()
    {
        return is_inited;
    }

    void Init();

    inline void Reset()
    {
        is_inited = false;
    }

    inline void SetF(const Eigen::MatrixXd &f)
    {
        F = f;
    }

    inline void SetF()
    {
        F << 1.0f, 0.0f, dt, 0.0f,
            0.0f, 1.0f, 0.0f, dt,
            0.0f, 0.0f, 1.0f, 0.0f,
            0.0f, 0.0f, 0.0f, 1.0f;
    }

    inline void SetP(const Eigen::MatrixXd &p)
    {
        P = p;
    }

    inline void SetQ(const Eigen::MatrixXd &q)
    {
        Q = q;
    }

    inline void SetHj(const Eigen::MatrixXd &hj)
    {
        Hj = hj;
    }

    inline void SetR(const Eigen::MatrixXd &r)
    {
        R = r;
    }

    /**
     * @brief Predict step.
     * 
     */
    void Predict();

    /**
     * @brief Update step.
     * 
     */
    void Update();
};

/**
 * @brief To update measurement vector and timestamp.
 * 
 * @param Z0 Z(0)
 * @param Z1 Z(1)
 * @param Z2 Z(2)
 * @param timestamp Current timestamp.
 */
void RecvRawData(float &Z0, float &Z1, float &Z2, uint32_t &timestamp)
{
    // Z0 = rho;
    // Z1 = phi;
    // Z2 = rho_dot;
    // timestamp = timestamp_new;
}

#endif
