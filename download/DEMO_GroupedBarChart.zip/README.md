# 运行环境
* windows 7, 8, 10
* Python 3+

# Python依赖
使用前请先通过`pip`包管理工具安装`numpy` `matplotlib` 这两个库依赖：
```python
pip install numpy
pip install matplotlib
```
若安装过程因网络问题很难成功，可尝试更换至国内镜像源进行安装，如使用清华镜像源：
```python
pip install -i https://pypi.tuna.tsinghua.edu.cn/simple numpy
pip install -i https://pypi.tuna.tsinghua.edu.cn/simple matplotlib
```

# 使用方法
1. 打开终端，运行脚本:
   ```bash
   python ./GroupedBarChart.py
   ```
2. 弹出Figure窗口，适当调整格式，调整保存统计结果。
