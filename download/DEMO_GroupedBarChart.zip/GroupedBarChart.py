import os
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt


class GroupedBarChart(object):
    def __init__(self):
        self.path_current = os.path.dirname(__file__)
        print(self.path_current)
        self.path_logs = [
            (self.path_current + "/" + i)
            for i in os.listdir(self.path_current)
            if (os.path.isfile(os.path.join(self.path_current, i))
                and i.endswith('.txt'))
        ]
        self.num_frames_total = 0
        self.num_frames_lost = 0
        self.list_valid_log_name = []
        self.list_frame_lost_percent = []
        self.list_frame_normal_percent = []
        # 字体设置，若不将'family'设置为中文相关字体，则无法正常显示中文
        self.font = {
            'family': 'Microsoft YaHei',
            'style': 'normal',
            'weight': 'normal',
            'size': 16
        }
        self.title = '标题'

    def Parse(self):
        for path_log in self.path_logs:
            log_name = path_log.split('/')[-1]
            log = open(path_log)
            for line in log.readlines():
                if 'Flag_DataFrame' in line:
                    self.num_frames_total += 1
                elif 'Flag_FrameLost' in line:
                    self.num_frames_lost += 1
                else:
                    pass

            if self.num_frames_total is not 0:
                self.list_valid_log_name.append(
                    log_name.split('_')[-1].split('.')[0])
                self.frame_lost_ratio = format(
                    self.num_frames_lost / self.num_frames_total * 100,
                    '.2f') if self.num_frames_total is not 0 else '#NA'
                self.list_frame_lost_percent.append(
                    float(self.frame_lost_ratio))
                self.list_frame_normal_percent.append(
                    100 - float(self.frame_lost_ratio))

            print('\nlog file: {}'.format(log_name))
            print('--------------------------------------------------------')
            print('num_frames_total: {}'.format(self.num_frames_total))
            print(' num_frames_lost: {}'.format(self.num_frames_lost))
            print('frame_lost_ratio: {}%'.format(self.frame_lost_ratio))
            print('--------------------------------------------------------\n')

            self.num_frames_total = 0
            self.num_frames_lost = 0

    def PlotSet(self):
        if len(self.list_valid_log_name) is not 0:
            ind = np.arange(len(self.list_valid_log_name))
            # bar的宽度
            width = 0.35
            self.fig, self.ax = plt.subplots()
            # bar1
            self.rects_frame_lost = self.ax.bar(
                ind - width / 2,
                self.list_frame_lost_percent,
                width,
                color="tomato",
                label="label1")
            # bar2
            self.rects_frame_normal = self.ax.bar(
                ind + width / 2,
                self.list_frame_normal_percent,
                width,
                color="steelblue",
                label="label2")
            # 设置纵坐标标签
            self.ax.set_ylabel('百分比 (%)', fontdict=self.font)
            # 设置坐标轴刻度大小
            plt.tick_params(labelsize=18)
            # 设置标题
            self.ax.set_title(self.title, fontdict=self.font)
            # 设置横坐标刻度
            self.ax.set_xticks(ind)
            # 设置横坐标刻度标签
            self.ax.set_xticklabels(
                self.list_valid_log_name, fontdict=self.font)
            # 设置图例：位置，字体
            self.ax.legend(loc='upper left', prop=self.font)
            print('average_frame_lost_ratio: {}%'.format(
                round(np.mean(self.list_frame_lost_percent), 2)))

    def AutoLabel(self):
        """
        为每一个bar打上标注
        """
        for rects in (self.rects_frame_lost, self.rects_frame_normal):
            for rect in rects:
                height = rect.get_height()
                self.ax.text(
                    rect.get_x() + rect.get_width() / 2.,
                    height + 1,
                    '%.2f' % height,
                    ha='center',
                    va='bottom',
                    fontsize=12)


def main():
    obj = GroupedBarChart()
    obj.Parse()
    obj.PlotSet()
    obj.AutoLabel()

    plt.show()


if __name__ == "__main__":
    main()