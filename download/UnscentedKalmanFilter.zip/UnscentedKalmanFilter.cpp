#include "math.h"

#include "UnscentedKalmanFilter.h"

/**
 * @brief Construct a new Unscented Kalman Filter object
 *
 */
UnscentedKalmanFilter::UnscentedKalmanFilter()
    : is_inited(false),
      just_begin_filt(false),
      timestamp_last(0),
      dt(0.0),
      n_x(5),
      n_x_aug(7),
      n_z(3),
      std_a(1.5),         // need to be tuned according to the performance of the ukf
      std_omega_dot(0.8), // need to be tuned according to the performance of the ukf
      Q(2, 2),
      std_rho(0.3),
      std_phi(0.03),
      std_rho_dot(0.3),
      R(n_z, n_z),
      kappa(0.0),
      weights(2 * n_x_aug + 1),
      X(n_x),
      P_x(n_x, n_x),
      X_aug(n_x_aug),
      P_x_aug(n_x_aug, n_x_aug),
      Sigmas_x_aug(n_x_aug, 2 * n_x_aug + 1),
      Sigmas_x_pred(n_x, 2 * n_x_aug + 1),
      Sigmas_z_pred(n_z, 2 * n_x_aug + 1),
      Z(n_z),
      P_z(n_z, n_z),
      P_xz(n_x, n_z),
      K(n_x, n_z),
      Z_meas(n_z),
      timestamp_now(0)
{
}

/**
 * @brief Destroy the Unscented Kalman Filter object
 *
 */
UnscentedKalmanFilter::~UnscentedKalmanFilter() {}

/**
 * @brief Initialize the unscented kalman filter.
 *
 */
void UnscentedKalmanFilter::Init()
{
    if (!IsInited())
    {
        double rho = Z_meas(0);
        double phi = Z_meas(1);
        double rho_dot = Z_meas(2);

        double px = rho * cos(phi);
        double py = rho * sin(phi);

        // the initial value of X(2) confused me: 0, a small value or the initial
        // measurement value of rho_dot?
        X << px, py, 0.0, 0.0, 0.0;

        P_x << 1.0, 0.0, 0.0, 0.0, 0.0,
            0.0, 1.0, 0.0, 0.0, 0.0,
            0.0, 0.0, 1.0, 0.0, 0.0,
            0.0, 0.0, 0.0, 1.0, 0.0,
            0.0, 0.0, 0.0, 0.0, 1.0;

        Q << std_a * std_a, 0.0,
            0.0, std_omega_dot * std_omega_dot;

        R << std_rho * std_rho, 0.0, 0.0,
            0.0, std_phi * std_phi, 0.0,
            0.0, 0.0, std_rho_dot * std_rho_dot;

        kappa = 3 - n_x_aug;

        weights.fill(1 / (2 * (n_x_aug + kappa)));
        weights(0) = kappa / (n_x_aug + kappa);

        is_inited = true;
        just_begin_filt = true;
    }
    else
    {
        just_begin_filt = false;
    }
}

/**
 * @brief Augment posterior probability distribution of X(k-1).
 *
 */
void UnscentedKalmanFilter::AugmentLastPosteriorPDF()
{
    if (just_begin_filt)
        return;

    // augment mean
    X_aug.head(5) = X;
    X_aug(5) = 0.0;
    X_aug(6) = 0.0;

    // augment covariance
    P_x_aug.fill(0.0);
    P_x_aug.topLeftCorner(5, 5) = P_x;
    P_x_aug(5, 5) = Q(0, 0);
    P_x_aug(6, 6) = Q(1, 1);
}

/**
 * @brief Sample the augmented posterior probability distribution of X(k-1).
 * 
 */
void UnscentedKalmanFilter::SigmaSample()
{
    if (just_begin_filt)
        return;

    double gamma = std::sqrt(n_x_aug + kappa);
    Eigen::MatrixXd chol_root = P_x_aug.llt().matrixL();

    Sigmas_x_aug.col(0) = X_aug;
    for (int i = 1; i < 2 * n_x_aug + 1; ++i)
    {
        if (i < n_x_aug + 1)
            Sigmas_x_aug.col(i) = X_aug + gamma * chol_root.col(i - 1);
        else
            Sigmas_x_aug.col(i) = X_aug - gamma * chol_root.col(i - n_x_aug - 1);
    }
}

/**
 * @brief Prediction step.
 *
 */
void UnscentedKalmanFilter::Predict()
{
    if (just_begin_filt)
        return;

    // predict sigma points of prior probability distribution of X(k)
    for (int i = 0; i < 2 * n_x_aug + 1; ++i)
    {
        double px = Sigmas_x_aug(0, i);
        double py = Sigmas_x_aug(1, i);
        double v = Sigmas_x_aug(2, i);
        double psi = Sigmas_x_aug(3, i);
        double omega = Sigmas_x_aug(4, i);
        double a = Sigmas_x_aug(5, i);
        double omega_dot = Sigmas_x_aug(6, i);

        Eigen::VectorXd state_trans_item_motion(n_x);
        Eigen::VectorXd state_trans_item_noise(n_x);

        state_trans_item_noise << 0.5 * a * cos(psi) * dt * dt,
            0.5 * a * sin(psi) * dt * dt,
            a * dt,
            0.5 * a * omega_dot * dt * dt,
            omega_dot * dt;

        if (std::fabs(omega_dot) > 0.001) // CTRV model
        {
            state_trans_item_motion << v / omega * (sin(psi + omega * dt) - sin(psi)),
                v / omega * (-cos(psi + omega * dt) + cos(psi)),
                0.0,
                omega * dt,
                0;
        }
        else // approximate CV model
        {
            state_trans_item_motion << v * cos(psi) * dt,
                v * sin(psi) * dt,
                0.0,
                omega * dt,
                0;
        }

        Sigmas_x_pred.col(i) = Sigmas_x_aug.head(5) + state_trans_item_motion + state_trans_item_noise;
    }

    // calculate approximate mean of prior PDF of X(k)
    X.fill(0.0);
    for (int i = 0; i < 2 * n_x_aug + 1; ++i)
        X += weights(i) * Sigmas_x_pred.col(i);

    // calculate approximate covariance of prior PDF of X(k)
    P_x.fill(0.0);
    for (int i = 0; i < 2 * n_x_aug + 1; ++i)
    {
        Eigen::VectorXd x_diff = Sigmas_x_pred.col(i) - X;
        NormalizeAngle(x_diff(3));

        P_x += weights(i) * x_diff * x_diff.transpose();
    }
}

/**
 * @brief Update step.
 *
 */
void UnscentedKalmanFilter::Update()
{
    if (just_begin_filt)
        return;

    // predict sigma points of probability distribution of Z(k)
    for (int i = 0; i < 2 * n_x_aug + 1; ++i)
    {
        double px = Sigmas_x_pred(0, i);
        double py = Sigmas_x_pred(1, i);
        double v = Sigmas_x_pred(2, i);
        double psi = Sigmas_x_pred(3, i);

        Sigmas_z_pred(0, i) = std::sqrt(px * px + py * py);
        Sigmas_z_pred(1, i) = atan2(py, px);
        Sigmas_z_pred(2, i) = (v * cos(psi) * px + v * sin(psi) * py) / Sigmas_z_pred(0, i);
    }

    // calculate approximate mean of PDF of Z(k)
    Z.fill(0.0);
    for (int i = 0; i < 2 * n_x_aug + 1; ++i)
        Z += weights(i) * Sigmas_z_pred.col(i);

    // calculate approximate covariance of PDF of Z(k)
    P_z.fill(0.0);
    for (int i = 0; i < 2 * n_x_aug + 1; ++i)
    {
        Eigen::VectorXd z_diff = Sigmas_z_pred.col(i) - Z;
        NormalizeAngle(z_diff(1));

        P_z += weights(i) * z_diff * z_diff.transpose();
    }
    P_z += R;

    // calculate cross covariance of X(k) and Z(k)
    P_xz.fill(0.0);
    for (int i = 0; i < 2 * n_x_aug + 1; ++i)
    {
        Eigen::VectorXd x_diff = Sigmas_x_pred.col(i) - X;
        NormalizeAngle(x_diff(3));

        Eigen::VectorXd z_diff = Sigmas_z_pred.col(i) - Z;
        NormalizeAngle(z_diff(1));

        P_xz += weights(i) * x_diff * z_diff.transpose();
    }

    // calculate kalman gain
    K = P_xz * P_z.inverse();

    // calculate mean of posterior PDF of X(k)
    Eigen::VectorXd z_diff = Z_meas - Z;
    NormalizeAngle(z_diff(1));
    X += K * z_diff;

    // calculate covariance of posterior PDF of X(k)
    P_x -= K * P_z * K.inverse();
}
