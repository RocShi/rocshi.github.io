#ifndef UNSCENTED_KALMAN_FILTER_
#define UNSCENTED_KALMAN_FILTER_

#include "Eigen/Dense"

class UnscentedKalmanFilter
{
private:
    bool is_inited;          // flag of initialization
    bool just_begin_filt;    // flag of just begining filt data
    uint64_t timestamp_last; // timestamp of last frame: us
    double dt;               // delta time: s

    int n_x;     // dimension of state vector X
    int n_x_aug; // dimension of augmented state vector X
    int n_z;     // dimension of measurement vector Z

    double std_a;         // standard deviation of longitudinal acceleration process noise: m/s^2
    double std_omega_dot; // standard deviation of yaw acceleration process noise: rad/s^2
    Eigen::MatrixXd Q;    // process noise covariance matrix

    double std_rho;     // standard deviation of range measurement noise: m
    double std_phi;     // standard deviation of bearing measurement noise: rad
    double std_rho_dot; // standard deviation of range rate measurement noise: m/s
    Eigen::MatrixXd R;  // measurement noise covariance matrix

    double kappa;            // unscented transform parameter κ
    Eigen::VectorXd weights; // weights vector of sigma points

    Eigen::VectorXd X;   // state vector
    Eigen::MatrixXd P_x; // state covariance matrix

    Eigen::VectorXd X_aug;         // augmented state vector
    Eigen::MatrixXd P_x_aug;       // augmented state covariance matrix
    Eigen::MatrixXd Sigmas_x_aug;  // sigma points of augmented posterior probability distribution of X(k-1)
    Eigen::MatrixXd Sigmas_x_pred; // sigma points of prior probability distribution of X(k)

    Eigen::MatrixXd Sigmas_z_pred; // sigma points of probability distribution of Z(k)

    Eigen::VectorXd Z;   // measurement vector
    Eigen::MatrixXd P_z; // measurement covariance matrix

    Eigen::MatrixXd P_xz; // cross covariance matrix of X and Z
    Eigen::MatrixXd K;    // kalman gain coefficient: K = P_xz * P_z.inverse()

public:
    Eigen::VectorXd Z_meas; // measurement value vector
    uint64_t timestamp_now; // timestamp of current frame: us

public:
    /**
     * @brief Construct a new Unscented Kalman Filter object
     *
     */
    UnscentedKalmanFilter();

    /**
     * @brief Destroy the Unscented Kalman Filter object
     *
     */
    ~UnscentedKalmanFilter();

    /**
     * @brief Return the initialization status of the ukf instance.
     *
     * @return bool
     */
    inline bool &IsInited() { return is_inited; }

    /**
     * @brief Reset the ukf instance.
     *
     */
    inline void Reset() { is_inited = false; }

    /**
     * @brief Normalize the input angle to [-PI, PI].
     *
     * @param angle
     */
    inline void NormalizeAngle(double &angle)
    {
        while (angle > M_PI)
            angle -= 2.0 * M_PI;
        while (angle < -M_PI)
            angle += 2.0 * M_PI;
    }

    /**
     * @brief To update measurement value vector and timestamp.
     *
     */
    inline void RecvRawData()
    {
        // Z_meas[0] = rho_new;
        // Z_meas[1] = phi_new;
        // Z_meas[2] = rho_dot_new;
        // timestamp_now = timestamp_new;

        dt = (timestamp_now - timestamp_last) / 1E6;
        timestamp_last = timestamp_now;
    }

    /**
     * @brief Initialization step.
     *
     */
    void Init();

    /**
     * @brief Augment posterior probability distribution of X(k-1).
     *
     */
    void AugmentLastPosteriorPDF();

    /**
     * @brief Sample the augmented posterior probability distribution of X(k-1).
     * 
     */
    void SigmaSample();

    /**
     * @brief Prediction step.
     *
     */
    void Predict();

    /**
     * @brief Update step.
     *
     */
    void Update();
};

#endif
