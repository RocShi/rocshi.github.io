#include "UnscentedKalmanFilter.h"

int main()
{
    UnscentedKalmanFilter ukf;

    while (true)
    {
        ukf.RecvRawData();

        ukf.Init();
        ukf.AugmentLastPosteriorPDF();
        ukf.SigmaSample();
        ukf.Predict();
        ukf.Update();
    }

    return 0;
}
