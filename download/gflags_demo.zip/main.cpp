#include <iostream>
#include <string>

#include "inc/flags.hpp"

int main(int argc, char *argv[]) {
  // flags' value are default before doing anything
  std::cout << "\nDefault value of flag_int32: " << FLAGS_demo_flag_int32
            << std::endl;
  std::cout << "Default value of flag_bool: " << FLAGS_demo_flag_bool
            << std::endl;

  // get flags from command line
  google::ParseCommandLineFlags(&argc, &argv, true);
  std::cout << "\nValue of flag_int32 from command line: "
            << FLAGS_demo_flag_int32 << std::endl;
  std::cout << "Value of flag_bool from command line: " << FLAGS_demo_flag_bool
            << std::endl;

  // get flags from a flag file, absolute path of the flag file is needed
  std::string flag_file_path =
      "/home/shipeng/Desktop/gflags_demo/flagfile.conf";
  google::SetCommandLineOption("flagfile", flag_file_path.c_str());
  std::cout << "\nValue of flag_int32 from flag file: " << FLAGS_demo_flag_int32
            << std::endl;
  std::cout << "Value of flag_bool from flag file: " << FLAGS_demo_flag_bool
            << std::endl;

  // modify the flags by manual within code
  FLAGS_demo_flag_int32 = 30;
  FLAGS_demo_flag_bool = true;
  std::cout << "\nValue of flag_int32 after modifing it by manual: "
            << FLAGS_demo_flag_int32 << std::endl;
  std::cout << "Value of flag_bool after modifing it by manual: "
            << FLAGS_demo_flag_bool << "\n"
            << std::endl;

  return 0;
}
