#include "../inc/flags.hpp"

DEFINE_int32(demo_flag_int32, 0, "A int32 demo flag.");
DEFINE_bool(demo_flag_bool, false, "A bool demo flag.");

DEFINE_validator(demo_flag_int32,
                 [](const char *flag_name, int32_t flag_value) -> bool {
                   return flag_value < 25;
                 });
