#ifndef FLAGS_HPP_
#define FLAGS_HPP_

#include "gflags/gflags.h"

DECLARE_int32(demo_flag_int32);
DECLARE_bool(demo_flag_bool);

#endif
