#ifndef SINGLETON_A_HPP_
#define SINGLETON_A_HPP_

#include <iostream>

#include "macro.hpp"

/**
 * @brief Singleton class without `Shutdown` method.
 * 
 */
class SingletonA
{
private:
    ~SingletonA() = default;

private:
    static int num;

public:
    static void GetNum()
    {
        std::cout << "\n number of instances of SingletonA: " << num << std::endl;
    }

    DECLARE_SINGLETON(SingletonA)
};

int SingletonA::num = 0;

SingletonA::SingletonA()
{
    ++num;
}

#endif
