#ifndef SINGLETON_B_HPP_
#define SINGLETON_B_HPP_

#include <iostream>

#include "macro.hpp"

/**
 * @brief Singleton class with `Shutdown` method.
 * 
 */
class SingletonB
{
private:
    ~SingletonB() = default;

private:
    static int num;

public:
    // `Shutdown` method should be declared as `public` for type traits
    void Shutdown();

    static void GetNum()
    {
        std::cout << "\n number of instances of SingletonB: " << num << std::endl;
    }

    DECLARE_SINGLETON(SingletonB)
};

int SingletonB::num = 0;

SingletonB::SingletonB()
{
    ++num;
}

void SingletonB::Shutdown()
{
    auto instance = Instance(false);
    if (instance != nullptr)
    {
        delete instance;
        num = 0;
    }

    std::cout << "\n SingletonB::Shutdown method was called." << std::endl;
}

#endif
