#include <thread>

#include "singleton_a.hpp"
#include "singleton_b.hpp"

template <typename T>
void ThreadFunc()
{
    std::this_thread::sleep_for(std::chrono::milliseconds(1000));
    T *p = T::Instance();
}

int main()
{
    std::thread tA1(ThreadFunc<SingletonA>);
    std::thread tA2(ThreadFunc<SingletonA>);
    std::thread tB1(ThreadFunc<SingletonB>);
    std::thread tB2(ThreadFunc<SingletonB>);

    tA1.join();
    tA2.join();
    tB1.join();
    tB2.join();

    SingletonA::GetNum();
    SingletonB::GetNum();

    SingletonA::CleanUp();
    SingletonB::CleanUp();

    SingletonA::GetNum();
    SingletonB::GetNum();

    return 0;
}
