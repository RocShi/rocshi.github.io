#ifndef FUNC_HPP_
#define FUNC_HPP_

#include <iostream>
#include <string>

void PrintString(const std::string &message);

void Func();

void Func1();

void Func2();

#endif
