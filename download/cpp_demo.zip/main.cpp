#include "inc/func.hpp"
#include <gperftools/profiler.h>

int main()
{
    ProfilerStart("cpp_demo_perf.prof");

    PrintString("This's a demo.");
    Func();

    ProfilerStop();

    return 0;
}
