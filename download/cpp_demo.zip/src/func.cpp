#include "../inc/func.hpp"

void PrintString(const std::string &message)
{
    std::cout << std::endl;
    std::cout << "Message: " << message << std::endl;
    std::cout << std::endl;
}

void Func()
{
    for (size_t i = 0; i < 1000; ++i)
    {
        Func1();
        Func2();
    }
}

void Func1()
{
    for (size_t i = 0; i < 10000000; ++i)
    {
    }
}

void Func2()
{
    for (size_t i = 0; i < 20000000; ++i)
    {
    }
}
