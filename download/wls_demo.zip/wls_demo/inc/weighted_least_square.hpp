#ifndef WEIGHTED_LEAST_SQUARE_HPP_
#define WEIGHTED_LEAST_SQUARE_HPP_

#include <vector>
#include <Eigen/Dense>

struct Point2D
{
    float x = 0.0f;
    float y = 0.0f;
    float weight = 1.0f;

    Point2D(float param_x, float param_y, float param_weight)
    {
        x = param_x;
        y = param_y;
        weight = param_weight;
    }
};

std::pair<bool, Eigen::VectorXf> WeightedLeastSquare(
    const std::vector<Point2D>& points, uint8_t orders);

#endif
