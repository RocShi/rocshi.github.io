import numpy as np
import matplotlib.pyplot as plt

# plot raw data
raw_data = np.loadtxt('data/raw_data.txt')
data_size = raw_data.shape[0]
plt.scatter(raw_data[:, 0], raw_data[:, 1], label='raw data')

# plot standard least square fitting result
standard_result = np.loadtxt('data/standard_least_square.txt')
standard_x = np.arange(1.0, data_size, 0.1)
standard_y = []
for x in standard_x:
    y = standard_result[0] + standard_result[1] * x + standard_result[
        2] * x**2 + standard_result[3] * x**3
    standard_y.append(y)
plt.plot(standard_x, standard_y, 'green', label='standard_least_square')

# plot weighted least square fitting result: weight of the first half of the
# points is higher
weighted_result_1 = np.loadtxt('data/weighted_least_square_1.txt')
weighted_x_1 = np.arange(1.0, data_size, 0.1)
weighted_y_1 = []
for x in weighted_x_1:
    y = weighted_result_1[0] + weighted_result_1[1] * x + weighted_result_1[
        2] * x**2 + weighted_result_1[3] * x**3
    weighted_y_1.append(y)
plt.plot(weighted_x_1, weighted_y_1, 'red', label='weighted_least_square_1')

# plot weighted least square fitting result: weight of the latter half of the
# points is higher
weighted_result_2 = np.loadtxt('data/weighted_least_square_2.txt')
weighted_x_2 = np.arange(1.0, data_size, 0.1)
weighted_y_2 = []
for x in weighted_x_2:
    y = weighted_result_2[0] + weighted_result_2[1] * x + weighted_result_2[
        2] * x**2 + weighted_result_2[3] * x**3
    weighted_y_2.append(y)
plt.plot(weighted_x_2, weighted_y_2, 'blue', label='weighted_least_square_2')

# plot setting
plot_font = {
    'family': 'Microsoft YaHei',
    'style': 'normal',
    'weight': 'normal',
    'size': 16
}
plt.xlabel('x', fontdict=plot_font)
plt.ylabel('y', fontdict=plot_font)
plt.tick_params(labelsize=12)
plt.legend(loc='upper left', prop=plot_font)
plt.show()
