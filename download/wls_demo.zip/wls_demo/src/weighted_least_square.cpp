#include <iostream>

#include "../inc/weighted_least_square.hpp"

std::pair<bool, Eigen::VectorXf> WeightedLeastSquare(
    const std::vector<Point2D>& points, uint8_t orders)
{
    auto samples_num = points.size();
    std::pair<bool, Eigen::VectorXf> failure_result{false, Eigen::VectorXf()};

    if (samples_num < orders + 1 || orders < 1)
    {
        std::cout << "Insufficient sampling points to fit a " << orders
                  << " order polynomial, please check it!" << std::endl;
        return failure_result;
    }

    Eigen::VectorXf sample_x(samples_num);
    Eigen::VectorXf sample_y(samples_num);
    Eigen::MatrixXf weight_mtx(samples_num, samples_num);
    float weight_sum = 0.0f, weight_sum_epsilon = 1E-6f;

    // step 1: data pre-processing
    for (size_t i = 0; i < samples_num; ++i)
    {
        if (points.at(i).weight < 0.0f)
        {
            std::cout << "Invalid weight " << points.at(i).weight
                      << " of point " << i << ", please check it!" << std::endl;
            return failure_result;
        }

        sample_x(i) = points.at(i).x;
        sample_y(i) = points.at(i).y;
        weight_sum += points.at(i).weight;
    }

    // step 2: normalize weight matrix
    if (weight_sum > weight_sum_epsilon)
    {
        for (size_t i = 0; i < samples_num; ++i)
            weight_mtx(i, i) = points.at(i).weight / weight_sum;
    }
    else
    {
        std::cout << "The total weight " << weight_sum
                  << " is too small, please check it!" << std::endl;
        return failure_result;
    }

    // step 3: construct Vandermonde matrix column by column
    Eigen::MatrixXf vandermonde_mtx(samples_num, orders + 1);
    vandermonde_mtx.col(0) = Eigen::VectorXf::Constant(samples_num, 1, 1);
    for (size_t i = 1; i < orders + 1; ++i)
    {
        vandermonde_mtx.col(i) =
            vandermonde_mtx.col(i - 1).array() * sample_x.array();
    }

    // step 4: solve coefficients vector of fitted polynomial
    Eigen::MatrixXf tmp = vandermonde_mtx.transpose() * weight_mtx;
    Eigen::VectorXf coeffs = (tmp * vandermonde_mtx).inverse() * tmp * sample_y;

    return {true, coeffs};
}
