#!/bin/bash

set -e

repo_dir=$(
    cd "$(dirname "${BASH_SOURCE[0]}")"
    pwd
)

rm -rf $repo_dir/data/*

source $repo_dir/build.sh

function run() {
    cd $repo_dir/bin
    ./wls_demo
}

run
