#include <iostream>
#include <string>
#include <fstream>
#include <random>

#include "inc/weighted_least_square.hpp"

std::vector<Point2D> GenData()
{
    std::ofstream fs;
    fs.open("../data/raw_data.txt", std::fstream::app);

    std::default_random_engine e;
    std::uniform_real_distribution<float> u(-500.0f, 500.0f);

    size_t points_num = 50;
    std::vector<Point2D> points;
    points.reserve(points_num);

    for (float x = 1; x <= static_cast<float>(points_num); ++x)
    {
        float y =
            4 + 3 * x + 1.2f * std::pow(x, 2) - 0.001f * std::pow(x, 3) + u(e);
        points.emplace_back(x, y, 1.0f);
        fs << x << " " << y;

        if (x < points_num) fs << std::endl;
    }
    fs.close();

    return points;
}

void FitData(const std::vector<Point2D>& points, const std::string& file_name)
{
    std::ofstream fs;
    auto result = WeightedLeastSquare(points, 3);
    if (result.first)
    {
        const auto& coeffs = result.second;
        std::string file_path = "../data/" + file_name;
        fs.open(file_path, std::fstream::app);
        fs << coeffs(0) << " " << coeffs(1) << " " << coeffs(2) << " "
           << coeffs(3);
        fs.close();
    }
}

int main()
{
    // generate random data
    auto points = GenData();

    // standard least square: all points have the same weights
    for (size_t i = 0; i < points.size(); ++i)
    {
        points.at(i).weight = 1.0f;
    }
    FitData(points, "standard_least_square.txt");

    // weighted least square: weight of the first half of the points is higher
    for (size_t i = 0; i < points.size(); ++i)
    {
        points.at(i).weight = i < points.size() / 2 ? 100.0f : 0.5f;
    }
    FitData(points, "weighted_least_square_1.txt");

    // weighted least square: weight of the latter half of the points is higher
    for (size_t i = 0; i < points.size(); ++i)
    {
        points.at(i).weight = i >= points.size() / 2 ? 100.0f : 0.5f;
    }
    FitData(points, "weighted_least_square_2.txt");

    return 0;
}
