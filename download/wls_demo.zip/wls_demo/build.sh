#!/bin/bash

function build() {
    if [ ! -d "build" ]; then
        mkdir build
    fi
    
    cd build
    cmake ..
    make
}

build
